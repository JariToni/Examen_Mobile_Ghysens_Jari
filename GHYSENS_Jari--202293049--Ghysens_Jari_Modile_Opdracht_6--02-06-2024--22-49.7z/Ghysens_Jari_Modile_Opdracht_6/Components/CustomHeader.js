// App.js
import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { MeetupProvider } from './Screens/MeetupContext';
import AllMeetupsScreen from './Screens/AllMeetupsScreen';
import MeetupDetailsScreen from './Screens/MeetupDetailsScreen';
import NewMeetupScreen from './Screens/NewMeetupScreen';
import AboutScreen from './Screens/AboutScreen';
import LoginScreen from './Screens/LoginScreen';
import RegisterScreen from './Screens/RegisterScreen';
import CustomHeader from './Components/CustomHeader';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function MeetupStack({ navigation }) {
  return (
    <Stack.Navigator
      screenOptions={({ route }) => ({
        header: () => (
          <CustomHeader
            title={route.name === 'AllMeetups' ? 'All Meetups' : route.name}
            navigation={navigation}
          />
        ),
      })}
    >
      <Stack.Screen name="AllMeetups" component={AllMeetupsScreen} />
      <Stack.Screen name="MeetupDetails" component={MeetupDetailsScreen} />
      <Stack.Screen name="NewMeetup" component={NewMeetupScreen} />
    </Stack.Navigator>
  );
}

function MainDrawer() {
  return (
    <Drawer.Navigator initialRouteName="Meetups">
      <Drawer.Screen name="Meetups" component={MeetupStack} />
      <Drawer.Screen name="About" component={AboutScreen} />
    </Drawer.Navigator>
  );
}

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, []);

  if (!user) {
    return (
      <GestureHandlerRootView style={{ flex: 1 }}>
        <NavigationContainer>
          <Stack.Navigator>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <MeetupProvider>
        <NavigationContainer>
          <MainDrawer />
        </NavigationContainer>
      </MeetupProvider>
    </GestureHandlerRootView>
  );
}

export default App;
