// Screens/AboutScreen.js
import React, { useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { getAuth } from 'firebase/auth';
import MeetupContext from './MeetupContext';

const AboutScreen = () => {
  const auth = getAuth();
  const user = auth.currentUser;
  const { meetups } = useContext(MeetupContext);
  const favoriteCount = meetups.filter(meetup => meetup.favorite).length;

  return (
    <View style={styles.container}>
      <Text>About the Meetup App</Text>
      {user ? (
        user.isAnonymous ? (
          <Text>You are logged in as an anonymous user.</Text>
        ) : (
          <>
            <Text>Display Name: {user.displayName}</Text>
            <Text>Email: {user.email}</Text>
          </>
        )
      ) : (
        <Text>No user is logged in.</Text>
      )}
      <Text>Favorite Meetups: {favoriteCount}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default AboutScreen;
