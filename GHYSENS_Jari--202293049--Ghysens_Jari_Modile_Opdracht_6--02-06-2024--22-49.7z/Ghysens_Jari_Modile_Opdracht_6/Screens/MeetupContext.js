// Screens/MeetupContext.js
import React, { createContext, useState, useEffect } from 'react';
import { collection, addDoc, getDocs, updateDoc, doc } from 'firebase/firestore';
import { db, auth } from '../firebase'; // Adjust the path as necessary
import { onAuthStateChanged } from 'firebase/auth';

const MeetupContext = createContext();

export const MeetupProvider = ({ children }) => {
  const [meetups, setMeetups] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      fetchMeetups();
    });
    return () => unsubscribe();
  }, []);

  const fetchMeetups = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'meetups'));
      const fetchedMeetups = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMeetups(fetchedMeetups);
    } catch (error) {
      console.error('Error fetching meetups:', error);
    }
  };

  const addMeetup = async (meetup) => {
    if (user && user.isAnonymous) {
      console.log('Anonymous users cannot add meetups');
      return;
    }
    try {
      const docRef = await addDoc(collection(db, 'meetups'), meetup);
      console.log('Meetup added with ID:', docRef.id);
      setMeetups(currentMeetups => [...currentMeetups, { id: docRef.id, ...meetup }]);
      await fetchMeetups(); // Fetch the updated list of meetups
    } catch (error) {
      console.error('Error adding meetup:', error);
    }
  };

  const toggleFavorite = async (meetupId) => {
    if (user && user.isAnonymous) {
      console.log('Anonymous users cannot modify meetups');
      return;
    }
    try {
      const meetupDoc = doc(db, 'meetups', meetupId);
      const currentMeetup = meetups.find(m => m.id === meetupId);
      const updatedMeetup = { ...currentMeetup, favorite: !currentMeetup.favorite };
      await updateDoc(meetupDoc, { favorite: updatedMeetup.favorite });
      setMeetups(meetups.map(m => (m.id === meetupId ? updatedMeetup : m)));
    } catch (error) {
      console.error('Error updating favorite status:', error);
    }
  };

  return (
    <MeetupContext.Provider value={{ meetups, addMeetup, fetchMeetups, toggleFavorite }}>
      {children}
    </MeetupContext.Provider>
  );
};

export default MeetupContext;
