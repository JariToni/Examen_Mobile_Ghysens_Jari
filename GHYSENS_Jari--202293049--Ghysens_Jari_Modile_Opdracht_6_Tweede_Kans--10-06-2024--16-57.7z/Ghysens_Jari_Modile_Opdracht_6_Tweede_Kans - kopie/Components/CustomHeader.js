import React, { useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MeetupContext from '../Screens/MeetupContext';

const CustomHeader = ({ title }) => {
  const { favoriteCount } = useContext(MeetupContext);

  return (
    <View style={styles.headerContainer}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.favoriteText}>Favorite: {favoriteCount}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    marginTop: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#f8f8f8',
    paddingHorizontal: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  favoriteText: {
    fontSize: 16,
    marginRight: 10,
  },
});

export default CustomHeader;
